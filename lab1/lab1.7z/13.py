t = tuple(map(int, input().split()))

print(t[0])