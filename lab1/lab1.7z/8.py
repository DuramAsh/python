base, height = map(int, input().split())

def calculate_area(base, heigh):
	return base * height / 2

print(calculate_area(base, height))