name, age, city = input().split()
print(f'{name}\n{age}\n{city}\n')