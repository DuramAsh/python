def sum_of_list(arr):
	return sum(arr)

l = list(map(int, input().split()))
print(sum_of_list(l))
