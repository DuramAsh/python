def string_length(s):
	return len(s)

s = input()
print(string_length(s))