def solve(x, y):
	return (x + y) ** 2

a, b = map(int, input().split())
print(solve(a, b))