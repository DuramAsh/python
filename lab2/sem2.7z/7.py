def solve(s, n):
	return s * n

s = input()
n = int(input())
print(solve(s, n))