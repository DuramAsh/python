import math

def solve(r):
    return (4/3) * math.pi * (r ** 3)

r = 6
print(solve(r))
